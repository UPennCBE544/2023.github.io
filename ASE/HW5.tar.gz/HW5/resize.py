#!/usr/bin/env python
import numpy as np

from ase import io
from espresso import espresso


atoms =  io.read('sto-bulk.traj') #Read trajectory

a =   #DFT lattice constant obtained previously

atoms.set_cell([a, a, a], scale_atoms=True)

traj=io.Trajectory('sto-bulk-opt.traj','w')

traj.write(atoms)



#!/usr/bin/env python
import numpy as np

from ase import io
from espresso import espresso

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


atoms =  io.read('sto-bulk.traj') #Read trajectory

convergence = {'energy':1e-5,     #SCF convergence settings   
                'mixing':0.05,
                'nmix':10,
                'maxsteps':500,
                'diag':'david'
                }

output = {'avoidio':False,       #QE output directives
        'removewf':True,
        'wf_collect':False}

kpts = [2, 3, 4, 5, 6, 7, 8]
energies = []

for k in kpts:

	calc = espresso(pw=600 , # Plane wave cutoff
    		dw=6000, # Density wave cutoff
    		nbands=-50,
    		smearing='gauss',
    		kpts=(k,k,k), # k-point (Brillouin) sampling
    		xc='PBE', #Exchange-correlation functional
    		parflags='-npool 2',
    		convergence=convergence,
    		outdir = 'calcdir', #QE generated files will be put here
    		output = output,) 


	atoms.set_calculator(calc)#Assign calculator to atoms

	energy = atoms.get_potential_energy()
	energies.append(energy)
	
	print 'k-points:', k, 'Total Energy (eV):', energy

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(kpts, energies,marker='o',color='b')
ax.set_xlabel('k-points')
ax.set_ylabel('Total Energy (eV)')
plt.tight_layout()
fig.savefig('k-point-convergence.png')

#!/usr/bin/env python

from ase.io import read

atoms = read('scf.out')

print(atoms.get_total_energy())





#!/usr/bin/env python

import matplotlib.pyplot as plt

with open('out') as f:
    energies = [float(line[:-2]) for line in f.readlines()]
kpts = [1,2,3,4,5,6,7,8]
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(kpts, energies,marker='o',color='b')
ax.set_xlabel('k-points')
ax.set_ylabel('Total Energy (eV)')
plt.tight_layout()
fig.savefig('k-point-convergence.png')







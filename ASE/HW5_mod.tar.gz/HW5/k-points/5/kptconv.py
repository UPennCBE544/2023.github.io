#!/usr/bin/env python
import numpy as np

from ase import io
from espresso import espresso

atoms =  io.read('mgo-bulk.traj') #Read trajectory

convergence = {'energy':1e-5,     #SCF convergence settings
                'mixing':0.05,
                'nmix':10,
                'maxsteps':500,
                'diag':'david'
                }

output = {'avoidio':False,       #QE output directives
        'removewf':True,
        'wf_collect':False}

k = input('Enter k-point (2-8): ')
energies = []

calc = espresso(pw=600, # Plane wave cutoff
    		dw=6000, # Density wave cutoff
    		nbands=-50,
    		smearing='gauss',
    		kpts=(k,k,k), # k-point (Brillouin) sampling
    		xc='BEEF-vdw', #Exchange-correlation functional
    		parflags='-npool 2',
    		convergence=convergence,
		onlycreatepwinp='pw.in',
    		outdir='calcdir', #QE generated files will be put here
    		output=output,)


atoms.set_calculator(calc)#Assign calculator to atoms
calc.initialize(atoms)

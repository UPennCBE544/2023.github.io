import os
import subprocess

# Get a list of all 'pw*' directories
pw_directories = [directory for directory in os.listdir() if directory.startswith("pw") and os.path.isdir(directory)]

# Sort the directories to ensure they are processed in numerical order
pw_directories.sort(key=lambda x: int(x[2:]))

# Loop through the 'pw*' directories and submit jobs
for directory in pw_directories:
    # Change the current working directory to the 'pw*' directory
    os.chdir(directory)

    # Find the 'anvil*.sub' file in the directory
    anvil_sub_file = [file for file in os.listdir() if file.startswith("anvil") and file.endswith(".sub")]

    if anvil_sub_file:
        # Submit the job using sbatch with the anvil*.sub file
        subprocess.call(['sbatch', anvil_sub_file[0]])

    # Return to the parent directory
    os.chdir('..')

print("All jobs submitted.")


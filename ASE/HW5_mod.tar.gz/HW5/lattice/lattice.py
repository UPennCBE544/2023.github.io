
#!/usr/bin/env python
import numpy as np
from ase import io
from ase import Atoms
from espresso import espresso
from ase.optimize import QuasiNewton
from ase.constraints import FixAtoms
import sys
import pickle
import time
import os
import sys
import subprocess
import shutil

atoms =  io.read('mgo-bulk.traj')
frames = 10
email = 'abc@gmail.com'

cell=atoms.get_cell() #Get cell dimensions
i = 0 # Initialize counter
var = []
linescp = [] #Initiate empty list
linescp.append('import os')
linescp.append('import sys')
linescp.append('import time')

atoms.set_pbc([True,True,True])

for x in np.linspace(0.85, 1.15, frames): #Varying the cell size and computing single point energies
	atoms.set_cell(cell*x, scale_atoms=True)
	calc1 = espresso(mode='scf',
			pw=500,             #plane-wave cutoff
               		dw=5000,                    #density cutoff
                	xc='BEEF-vdw',          #exchange-correlation functional
                	kpts=(4,4,4),       #k-point sampling;
                	nbands=-40,             #20 extra bands besides the bands needed to hold
                	sigma=0.1,
                	nosym=True,
                	convergence= {'energy':1e-5,
                    	'mixing':0.7,
                    	'nmix':14,
                    	'maxsteps':2000,
                    	'diag':'david'
                    	},  #convergence parameters
                 	dipole={'status':False}, #dipole correction to account for periodicity in z
                 	output = {'avoidio':False,
                    	'removewf':True,
                    	'disk_io':'none',
                    	'wf_collect':False},
                 	spinpol=False,
                 	onlycreatepwinp='pw'+ str(i) +'.in',
                 	outdir='calc'+ str(i) +'')   #output directory for Quantum Espresso files
	atoms.set_calculator(calc1)
	calc1.initialize(atoms)

	lines=[
	'#!/bin/bash',
	'',
	'#SBATCH -N  1',
	'#SBATCH --tasks-per-node=16',
	'#SBATCH -t 1-00:00:00',
	'#SBATCH -J scf'+ str(i) +'',
	'#SBATCH -e err.%j',
	'#SBATCH -o out.%j',
	'#SBATCH --mail-user='+ email +'',     #Make sure to edit your email here
	'#SBATCH --mail-type=ALL',
	'#SBATCH -A eve210010',
	'',
	'####### Quantum-Espresso ####',
	'',
	'cd $SLURM_SUBMIT_DIR',
	'',
	'mkdir -p $SCRATCH/$SLURM_JOBID',
	'cp pw'+ str(i) +'.in $SCRATCH/$SLURM_JOBID',
	'',
	'cd $SCRATCH/$SLURM_JOBID',
	'',
	"mpirun /home/x-syj1022/apps/qe-7.2/bin/pw.x -nd 4 <pw"+ str(i) +".in> pw.out",
	'',
	'cp pw.out $SLURM_SUBMIT_DIR',
	'###############################']

	with open('anvil'+ str(i) +'.sub', 'w') as g:
                 g.write('\n'.join(lines))
	linescp.append("os.system('sbatch anvil"+ str(i) +".sub')")
	linescp.append("time.sleep(30)")
	i = i+1

# Create directories for pw files and move files
for file in os.listdir('.'):
    if file.startswith('pw') and file.endswith('.in'):
        dir_name = file.replace('.in', '')
        os.makedirs(dir_name, exist_ok=True)
        shutil.move(file, dir_name)

# Copy anvil#.sub files to the corresponding pw* directories
for chestnut_file in os.listdir('.'):
    if chestnut_file.startswith('anvil') and chestnut_file.endswith('.sub'):
        pw_dir = chestnut_file.replace('anvil', 'pw').replace('.sub', '')
        if os.path.isdir(pw_dir):
            shutil.copy(chestnut_file, pw_dir)

# Remove all anvil#.sub and pw#.inp files in the current directory
for file in os.listdir('.'):
    if (file.startswith('pw') and file.endswith('.in')) or (file.startswith('anvil') and file.endswith('.sub')):
        os.remove(file)


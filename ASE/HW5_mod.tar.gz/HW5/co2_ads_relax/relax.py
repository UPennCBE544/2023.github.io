#!/usr/bin/env python
import numpy as np

from ase import io
from ase import Atoms
from espresso import espresso
from ase.optimize import QuasiNewton
from ase.constraints import FixAtoms
import sys
import pickle

slab =  io.read('mgo-100.traj')   #read slab
slab.set_pbc([True,True,True])   #set periodic boundaries in all directions to true


calc = espresso(pw=500,             #plane-wave cutoff
                dw=5000,                    #density cutoff
                xc='BEEF-vdw',          #exchange-correlation functional
                kpts=(4,4,1),	    #k-point sampling;
                nbands=-30,             #30 extra bands besides the bands needed to hold
                sigma=0.1,
                opt_algorithm = 'bfgs',
                fmax = 0.03,
                nstep=200,
                nosym=True,
                convergence= {'energy':1e-5,
                    'mixing':0.1,
                    'nmix':10,
                    'mix':4,
                    'maxsteps':2000,
                    'diag':'david'
                    },  #convergence parameters
                 dipole={'status':True}, #dipole correction to account for periodicity in z
                 output = {'avoidio':False,
                    'removewf':True,
                    'wf_collect':False},
                 spinpol=False,
                 parflags='-npool 1',
                 onlycreatepwinp='pw.in',
                 outdir='.')   #output directory for Quantum Espresso files

slab.set_calculator(calc)
calc.initialize(slab)


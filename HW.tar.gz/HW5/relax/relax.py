#!/usr/bin/env python
from ase import Atoms, Atom
from ase.calculators.vasp import Vasp
from ase.io import read,write
import numpy as np
            
slab=read('LiCoO2-104.traj')
calc = Vasp(prec='normal',	#scf accuracy
            encut=520,		#plane-wave cutoff
            xc='PBE',		#functional		
            lreal='Auto',	#sampling space
            kpts=[4,4,1],	#kpoint sampling
            nsw = 99,		#max number of ionic steps
            ibrion = 2,		#ion iteration steps
            ispin = 2,		#spin polarized
            amix_mag = 0.800000,#mixing parameters
            bmix = 0.000100,
            bmix_mag= 0.000100,
            amix = 0.20000,
            sigma = 0.05000,	#smearing
            ediff = 2.00e-04,	#energy difference for scf convergence
            ediffg = -3.00e-02,	#force  cutoff for overall convergence
            algo ='fast',
            ismear = -5,	#smearing type 
            nelm = 250,		#max number of electronic steps
            ncore = 16,	
            lasph= True,
            ldautype = 2,	#Use Hubbard U
            lmaxmix = 4,
            lorbit = 11,
            ldau = True,
            ldauprint = 2,
            ldau_luj={'Co':{'L':2, 'U':3.32, 'J':0},
                      'Li':{'L':-1, 'U':0.0, 'J':0.0},
                      'O':{'L':-1, 'U':0.0, 'J':0.0}
                      },
            lvtot = False,
            lwave = False,
            lcharg = False,
	    gamma=True,		#center at gamma point
)
calc.calculation_required = lambda x, y: True
slab.set_calculator(calc)
pe=slab.get_potential_energy()
#####
ana =  Vasp(restart=True)
pend = ana.get_atoms()

forces=pend.get_forces().ravel()
max_force=max([abs(x) for x in forces])

pe = pend.get_potential_energy()
#mag = pend.get_magnetic_moments()

#pend.set_initial_magnetic_moments(mag)
#print mag
write('fin.traj',pend)

vol=pend.get_cell()

print "Energy = "+str(pe)
print "max_forces = "+str(max_force)

#!/usr/bin/env python
import numpy as np

from ase import io
from espresso import espresso


atoms =  io.read('LiCoO2-bulk.traj') #Read trajectory

a = 2.835  #DFT lattice constant obtained previously
c=  4.990

a0=[a,0,0]
b0=[a/2,(a/2)*np.sqrt(3),0]
c0=[a/2,a/(2*np.sqrt(3)),np.sqrt(c**2-(a/2)**2-(a/(2*np.sqrt(3)))**2)]

atoms.set_cell([a0, b0, c0], scale_atoms=True)
print(atoms.get_cell())

traj=io.Trajectory('LiCoO2-bulk-opt.traj','w')

traj.write(atoms)



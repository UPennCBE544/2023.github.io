#!/usr/bin/env/ python
from ase.io import read,write
from ase.build import surface,bulk
from ase import atoms
from ase.visualize import view

p=read('LiCoO2-bulk-opt.traj')
s1 = surface(p, (1,0,4), 6)
s1.center(vacuum=10,axis=2)
write('LiCoO2-104.traj',s1)

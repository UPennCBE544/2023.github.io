#!/usr/bin/env python
import numpy as np

from ase import io
from ase.calculators.vasp import Vasp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


atoms =  io.read('LiCo2-bulk-opt.traj') #Read trajectory

kpts = [ 3, 4, 5, 6, 7, 8,9]
kpt2=[2,2,2,3,3,3,4]
energies = []
d=2

for i in range(0,len(kpts)):

        calc = Vasp(prec='accurate',
            encut=520,
            xc='PBE',
            lreal='False',
            isym=-1,
	    kpts=(kpts[i],kpts[i],kpt2[i]),
            nsw = 0,
            ibrion = 2,
            ispin = 2,
            amix_mag = 0.800000,
            bmix = 0.000100,
            bmix_mag= 0.000100,
            amix = 0.20000,
            sigma = 0.05000,
            ediff = 2.00e-04,
            ediffg = -2.00e-02,
            algo ='fast',
            ismear = -5,
            nelm = 250,
            ncore = 16,
            lasph= True,
            ldautype = 2,
            lmaxmix = 4,
            lorbit = 11,
            ldau = True,
            ldauprint = 2,
            ldau_luj={'Co':{'L':2, 'U':3.32, 'J':0.0},
                      'Li':{'L':-1, 'U':0.0, 'J':0.0},
                      'O':{'L':-1, 'U':0.0, 'J':0.0}
                      },
            lvtot = False,
            lwave = False,
            lcharg = False,
	    gamma=True,
)

	atoms.set_calculator(calc)#Assign calculator to atoms

	energy = atoms.get_potential_energy()
	energies.append(energy)

	print 'k-points:', kpts[i], 'Total Energy (eV):', energy

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(kpts, energies,marker='o',color='b')
ax.set_xlabel('k-points')
ax.set_ylabel('Total Energy (eV)')
plt.tight_layout()
fig.savefig('k-point-convergence.png')

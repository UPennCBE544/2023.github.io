#!/usr/bin/env python
import numpy as np

from ase import io
from ase import Atoms
from espresso import espresso
from ase.optimize import QuasiNewton
from ase.constraints import FixAtoms
import sys
import pickle

slab =  io.read('init.traj')
slab.set_pbc([True,True,True])

calc = espresso(pw=600,             #plane-wave cutoff
                dw=6000,                    #density cutoff
                xc='PBE',          #exchange-correlation functional
                kpts=(5,5,5),       #k-point sampling;
                nbands=-20,             #20 extra bands besides the bands needed to hold
		smearing='gauss',
                sigma=0.1,
		nstep=1000,
                mode = 'vc-relax',
                cell_dynamics = 'bfgs',
                opt_algorithm = 'bfgs',
                fmax = 0.03,
		#cell_factor=3,
		nosym=False,
                convergence= {'energy':1e-5,
                    'mixing':0.1,
                    'nmix':10,
                    'mix':4,
                    'maxsteps':500,
                    'diag':'david'
                    },  #convergence parameters
                 dipole={'status':False}, #dipole correction to account for periodicity in z
                 output = {'avoidio':False,
                    'removewf':True,
                    'wf_collect':False},
                 spinpol=False,
                 parflags='-npool 2',
                 onlycreatepwinp='pw.inp',
                 outdir='calcdir')   #output directory for Quantum Espresso files

#calc.calculation_required = lambda x, y: True
slab.set_calculator(calc)
#slab.get_potential_energy()

calc.initialize(slab)

#relaxed = calc.get_final_structure()
#io.write('relaxed.traj',relaxed)
#density=calc.extract_ae_charge_density()
#f = open('chg.pickle', 'w')
#pickle.dump(density, f)
#f.close()

#f=open('chg.pickle')
#origin,cell,density=pickle.load(f)
#f.close()

#io.write('density.cube',slab,data=density)

#!/usr/bin/env python

from ase import Atoms, Atom
from ase.calculators.vasp import Vasp
from ase.io import read,write
from ase.build import add_adsorbate,molecule

p=read('bare.traj')
EC =read('EC.traj')
add_adsorbate (p, h2o, height = 1, position = (3.429,22.484),mol_index=20)
write('init.traj',p)


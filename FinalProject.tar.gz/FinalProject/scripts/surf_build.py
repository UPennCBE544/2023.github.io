#!/usr/bin/env python
import numpy as np

from ase import io
from espresso import espresso
from ase import build
from ase.geometry import get_layers
import sys
from ase.optimize import BFGS

atoms =  io.read('opt.traj') #Optimized bulk FCC
traj=io.Trajectory('init.traj','w')
cell=atoms.get_cell() #Get cell of opt.traj
symb = atoms.get_chemical_symbols()
s1=build.surface(atoms, (1,1,0), 5) #cut a surface normal to the [1,1,0] direction and make it 5 layers deep in the z-direction.
s1.center(vacuum=10, axis=2) #center the cell and add 10 Angstroms of vacuum to both sides of the slab in the z-direction

traj.write(s1)

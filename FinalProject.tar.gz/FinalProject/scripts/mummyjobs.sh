#!/bin/sh
espdir='esp.log'
squeue -u $USER -t R|sed 1d|awk '{print $1}' > jobidlist

for i in `less jobidlist`
do
    #echo $i
    wdline=`scontrol show job $i | grep WorkDir`  
    IFS='= ' read -a array <<< $wdline
    workdir=${array[1]}
    #echo $workdir
    if [ -e $workdir/INCAR ]
    then
        flag=`tail -1 $workdir/out.$i|grep "Conflicting CPU frequencies"`
        t1=`stat -c %Y $workdir/OUTCAR`
    else
        flag=`tail -1 $workdir/calcdir/log|grep "Conflicting CPU frequencies"`
        t1=`stat -c %Y $workdir/calcdir/log`
    fi

    #echo $flag
    if [[ ! -z $flag ]]
    then
        echo "$i\t$workdir"
        echo $flag
        echo "WARNING: MUMMY job found"
        tc=`date +%s`
        tdiff=`echo "($tc-$t1)/60.0"|bc -l`
        echo "$mins hasn't been updated for  $tdiff mins! "
    fi

done

rm -f jobidlist


#!/usr/bin/env python
import numpy as np

from ase import io
from ase import Atoms
from espresso import espresso
from ase.optimize import QuasiNewton


slab =  io.read('init.traj')
slab.set_pbc([True,True,True])


calc = espresso(pw=500,             #plane-wave cutoff
                dw=5000,                    #density cutoff
                xc='PBE',          #exchange-correlation functional
                kpts=(5,5,1),       #k-point sampling;
                nbands=-20,             #20 extra bands besides the bands needed to hold valence electrons
                sigma=0.1,
		nosym=True,
                convergence= {'energy':1e-5,
                    'mixing':0.1,
                    'nmix':10,
                    'mix':4,
                    'maxsteps':500,
                    'diag':'david'
                    },  #convergence parameters for SCF
                 dipole={'status':True}, #dipole correction to account for periodicity in z
                 output = {'avoidio':False,
                    'removewf':True,
                    'wf_collect':False},
                 spinpol=False,
                 parflags='-npool 2 -nd 4',
                 outdir='calcdir')   #output directory for Quantum Espresso files


slab.set_calculator(calc)

qn=QuasiNewton(slab,trajectory='opt.traj',logfile='opt.log')
qn.run(fmax=0.03) #Optimization and force cut-off for convergence


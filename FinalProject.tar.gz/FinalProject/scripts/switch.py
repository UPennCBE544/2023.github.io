
from ase import Atom,Atoms
from ase.calculators.vasp import Vasp
from ase.io import read, write


calc = Vasp(restart=True)
atoms = calc.get_atoms()
mag=atoms.get_magnetic_moments()
print mag
atoms.set_initial_magnetic_moments
write('mag.traj',atoms)

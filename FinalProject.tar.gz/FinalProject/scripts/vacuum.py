from ase.io import read,write

slab = read('init.traj')
slab.center(vacuum=10,axis=2)

write('init.traj',slab)

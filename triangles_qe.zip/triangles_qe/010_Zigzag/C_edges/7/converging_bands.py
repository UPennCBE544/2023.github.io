
from ase import io
from espresso import espresso
from ase.optimize import BFGS
mxene=io.read('init.traj')

kx, ky, kz =4, 1, 1

mxene.set_pbc([True,True,True])

calc = espresso(pw= 700,
	       mode = 'bands',           #plane-wave cutoff
               dw=700*10,                    #density cutoff
               xc='BEEF-vdW',          #exchange-correlation functional
               kpts=(kx, ky, kz),    #k-point sampling;
               nbands=-20,             #100 extra bands besides the bands needed to hold
               #the valence  electrons
               sigma=0.1,
               convergence= {'energy':1e-6,
               'mixing':0.1,
               'nmix':10,
               'mix':4,
               'maxsteps':500,
               'diag':'david'},    #convergence parameters
               dipole={'status':True}, #diploe correction to account for periodicity in z
               spinpol=False,
               
	       output={'avoidio':False,
                    'removewf':True,
                    'wf_collect':False},
	       onlycreatepwinp = 'bands.in',
               parflags='-npool 2 -nd 25',
	       outdir='calcdir')  #output directory for Quantum Espresso

mxene.set_calculator(calc)
#calc.calc_bandstructure(mxene,nbands = 20)
calc.initialize(mxene)
#qn = BFGS(mxene, trajectory='Relax3.traj')
#qn.run(fmax=0.5)
